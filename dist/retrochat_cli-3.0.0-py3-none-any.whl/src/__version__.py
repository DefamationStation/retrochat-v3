# Version information for RetroChat v3
__version__ = "3.0.0"
__author__ = "DefamationStation"
__description__ = "Multi-Provider AI Chat Application"
