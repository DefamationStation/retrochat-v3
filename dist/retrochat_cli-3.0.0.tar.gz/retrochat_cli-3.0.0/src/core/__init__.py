"""
Core modules for RetroChat.

This package contains the core managers and business logic for the application.
"""
